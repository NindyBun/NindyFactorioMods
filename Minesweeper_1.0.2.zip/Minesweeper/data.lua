require("__NindyCore__/scripts/values.lua")
require("scripts.values")
require("prototypes.sprites")